#########################################################################
# File Name: for1.sh
# Author: qianghua jiang
# mail: 240437339@qq.com
# Created Time: Fri 04 Sep 2015 12:26:56 AM PDT
#########################################################################
#!/bin/bash
for i in 1 2 3 4 5
do
	echo $i
done
