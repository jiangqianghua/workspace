#########################################################################
# File Name: lsfile_for.sh
# Author: qianghua jiang
# mail: 240437339@qq.com
# Created Time: Fri 04 Sep 2015 12:30:28 AM PDT
#########################################################################
#!/bin/bash
   
#cd /target
ls *.tar.gz > ls.log
ls *.tgz >> ls.log
